TERRAVALE  (step 2 build)
A 3D creature-catching island for phones, with turn-based battles.
Everything is original: 12 creatures, 8 types, no third-party characters.

HOW TO RUN
1. Quick test: open index.html in Chrome or Safari. It needs internet the first
   time (it loads three.js and fonts).
2. On a phone: upload this whole folder to any static host (GitHub Pages,
   Netlify, Cloudflare Pages) and open the link on the phone. Add it to the
   home screen to play full screen.
3. Local network: in this folder run  python3 -m http.server 8000  and open
   http://YOUR-COMPUTER-IP:8000 on the phone (same Wi-Fi).
4. Offline: put three.min.js in the vendor folder (see the note inside it).

CONTROLS
- Drag the left half of the screen to move, the right half to look around.
- JUMP and RUN buttons are bottom right. Tap the clock to skip 3 hours.
- Tap BATTLE when a creature is close. Weaken it, then throw an orb.
- LOG shows your creatures and lets you pick your lead partner.
- HD / LD switches graphics quality (it also drops to LD if the game lags).
- Keyboard: WASD move, Space jump, Shift run, E battle, L log.

SAVING
Your party, levels and HP are saved in the browser (localStorage) on the device.

ROADMAP
Step 1  Open world, day and night, creature spawns   (done)
Step 2  Battles, levels, 12 creatures                (done)
Step 3  Multiplayer (needs a small server)           (next)
